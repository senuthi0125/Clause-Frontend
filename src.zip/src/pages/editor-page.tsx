import { useEffect, useState } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { ArrowLeft, Brain, Loader2 } from "lucide-react";
import AppLayout from "@/components/layout/app-layout";
import { contractsApi, aiApi } from "@/services/api";
import type { Contract } from "@/types";

const AI_SUMMARY = [
  { text: "Vendor Agreement Renewal due next week", color: "#f59e0b" },
  { text: "Software License Agreement expires this Friday", color: "#6366f1" },
  { text: "Service Level Agreement revision due Thursday", color: "#10b981" },
  { text: "Employment Contract updates due next Monday", color: "#f43f5e" },
  { text: "Maintenance Contract renewal reminder", color: "#8b5cf6" },
];

export default function EditorPage() {
  const { contractId } = useParams<{ contractId: string }>();
  const navigate = useNavigate();
  const [contract, setContract] = useState<Contract | null>(null);
  const [loading, setLoading] = useState(true);
  const [analyzing, setAnalyzing] = useState(false);

  useEffect(() => {
    if (!contractId) return;
    contractsApi.get(contractId).then((res) => setContract(res.data)).catch(() => {}).finally(() => setLoading(false));
  }, [contractId]);

  const runAnalysis = async () => {
    if (!contractId) return;
    setAnalyzing(true);
    try { await aiApi.analyzeContract(contractId); const res = await contractsApi.get(contractId); setContract(res.data); }
    catch { alert("Analysis failed."); }
    finally { setAnalyzing(false); }
  };

  if (loading) return <AppLayout title="AI analytics"><div className="flex items-center justify-center py-20"><Loader2 className="h-6 w-6 animate-spin text-[#9a9aa6]" /></div></AppLayout>;
  if (!contract) return <AppLayout title="AI analytics"><div className="py-20 text-center text-[#9a9aa6]">Contract not found.</div></AppLayout>;

  const analysis = contract.ai_analysis;

  return (
    <AppLayout title="AI analytics">
      <div className="mb-4 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <button onClick={() => navigate(`/contracts/${contractId}`)} className="rounded-xl p-2 hover:bg-gray-100"><ArrowLeft size={18} /></button>
          <h2 className="text-[16px] font-semibold text-[#1a1a2e]">{contract.title}</h2>
        </div>
        <button onClick={runAnalysis} disabled={analyzing}
          className="flex items-center gap-1.5 rounded-xl border border-[#e0e0ea] px-4 py-2 text-[12px] font-medium text-[#4a4a5a] hover:bg-gray-50 disabled:opacity-50">
          {analyzing ? <Loader2 size={14} className="animate-spin" /> : <Brain size={14} />}
          {analyzing ? "Analyzing…" : "Run AI Analysis"}
        </button>
      </div>

      <h3 className="mb-5 text-[20px] font-bold text-[#1a1a2e]">Contract Analytics</h3>

      <div className="grid grid-cols-[1.3fr_0.7fr] gap-6">
        {/* Document */}
        <div className="card min-h-[600px] p-8">
          <div className="mx-auto max-w-[520px] text-[11px] leading-relaxed text-[#1e1e1f]">
            <h2 className="mb-2 text-center text-[14px] font-bold">{contract.title}</h2>
            <p className="mb-6 text-center text-[10px] text-[#8a8a9a]">
              This {contract.contract_type?.replace(/_/g, " ")} Agreement is made on {new Date(contract.start_date).toLocaleDateString("en-US", { month: "long", day: "numeric", year: "numeric" })} between the parties listed herein.
            </p>
            {[
              { title: "1. Purpose", body: "This Agreement outlines the terms and conditions for the services to be provided by Contractor to Client." },
              { title: "2. Scope of Work", body: "Contractor will provide services as agreed upon by both parties, including any deliverables specified in attached schedules." },
              { title: "3. Deliverables", body: "Contractor will deliver all agreed outputs within the timeframes specified, including source files and documentation." },
              { title: "4. Payment Terms", body: `Payment shall be made according to the agreed schedule: 40% upfront, 30% at midpoint, 30% on completion.${contract.payment_terms ? ` Terms: ${contract.payment_terms}.` : ""}` },
            ].map((s) => (
              <div key={s.title} className="mb-4">
                <h3 className="mb-1 text-[12px] font-bold">{s.title}</h3>
                <p className="text-[10px] leading-5 text-[#4a4a5a]">{s.body}</p>
              </div>
            ))}
            {analysis?.extracted_clauses?.map((clause, i) => (
              <p key={i} className="mt-2 text-[10px]">{i + 5}. {clause}</p>
            ))}
          </div>
        </div>

        {/* Sidebar */}
        <div className="space-y-5">
          <div className="card p-5">
            <h3 className="mb-4 text-[13px] font-bold text-[#1a1a2e]">AI Summary</h3>
            <div className="space-y-2.5">
              {AI_SUMMARY.map((item, i) => (
                <div key={i} className="flex items-start gap-2">
                  <span className="mt-1.5 h-2 w-2 shrink-0 rounded-full" style={{ background: item.color }} />
                  <p className="text-[11px] leading-relaxed text-[#4a4a5a]">{item.text}</p>
                </div>
              ))}
            </div>
          </div>
          <div className="card p-5">
            <h3 className="mb-4 text-[13px] font-bold text-[#1a1a2e]">Risk Score</h3>
            <div className="flex flex-col items-center py-4">
              <div className="flex h-24 w-24 items-center justify-center rounded-full border-8 border-[#1a1a2e]">
                <div className="text-center">
                  <p className="text-[22px] font-bold text-[#1a1a2e]">{analysis?.risk_score ?? 72}</p>
                </div>
              </div>
              <p className="mt-3 text-[11px] text-[#8a8a9a]">Felicidade (NPS)</p>
              {analysis && <p className={`mt-1 text-[11px] font-semibold capitalize ${analysis.risk_level === "high" ? "text-red-500" : analysis.risk_level === "medium" ? "text-amber-500" : "text-emerald-500"}`}>{analysis.risk_level} Risk</p>}
            </div>
          </div>
        </div>
      </div>
    </AppLayout>
  );
}