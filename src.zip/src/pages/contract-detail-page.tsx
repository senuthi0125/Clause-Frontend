import { useEffect, useState } from "react";
import { useParams, useNavigate } from "react-router-dom";
import AppLayout from "@/components/layout/app-layout";
import { contractsApi, workflowsApi, approvalsApi, aiApi } from "@/services/api";
import type { Contract, Workflow, Approval } from "@/types";
import { Badge } from "@/components/ui/badge";
import { ArrowLeft, FileText, Users, Calendar, DollarSign, Brain, MessageSquare, Loader2, CheckCircle2, Circle, Clock, XCircle, ChevronRight } from "lucide-react";

const STATUS_STYLE: Record<string, string> = {
  active: "bg-green-100 text-green-700",
  draft: "bg-gray-100 text-gray-600",
  expired: "bg-red-100 text-red-700",
  terminated: "bg-orange-100 text-orange-700",
  renewed: "bg-blue-100 text-blue-700",
};

export default function ContractDetailPage() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const [contract, setContract] = useState<Contract | null>(null);
  const [workflows, setWorkflows] = useState<Workflow[]>([]);
  const [approvals, setApprovals] = useState<Approval[]>([]);
  const [loading, setLoading] = useState(true);
  const [analyzing, setAnalyzing] = useState(false);
  const [tab, setTab] = useState<"details" | "workflow" | "ai">("details");
  const [comment, setComment] = useState("");
  const [acting, setActing] = useState(false);

  const fetchData = () => {
    if (!id) return;
    setLoading(true);
    Promise.all([
      contractsApi.get(id),
      workflowsApi.getByContract(id).catch(() => ({ data: [] })),
      approvalsApi.getByContract(id).catch(() => ({ data: [] })),
    ]).then(([cRes, wRes, aRes]) => {
      setContract(cRes.data);
      setWorkflows(Array.isArray(wRes.data) ? wRes.data : []);
      setApprovals(Array.isArray(aRes.data) ? aRes.data : []);
    }).catch(() => {}).finally(() => setLoading(false));
  };

  useEffect(() => { fetchData(); }, [id]);

  const runAiAnalysis = async () => {
    if (!id) return;
    setAnalyzing(true);
    try {
      await aiApi.analyzeContract(id);
      const res = await contractsApi.get(id);
      setContract(res.data);
      setTab("ai");
    } catch { alert("AI analysis failed."); }
    finally { setAnalyzing(false); }
  };

  if (loading) return <AppLayout title="Contract Details"><div className="flex items-center justify-center py-20"><Loader2 className="h-6 w-6 animate-spin text-[#9a9aa6]" /></div></AppLayout>;
  if (!contract) return <AppLayout title="Contract Details"><div className="py-20 text-center text-[#9a9aa6]">Contract not found.</div></AppLayout>;

  const workflow = workflows[0];
  const analysis = contract.ai_analysis;

  return (
    <AppLayout title="Contract Details">
      {/* Header */}
      <div className="mb-5 flex items-start justify-between">
        <div className="flex items-center gap-3">
          <button onClick={() => navigate("/contracts")} className="rounded-xl p-2 hover:bg-gray-100"><ArrowLeft size={18} /></button>
          <div>
            <h2 className="text-[18px] font-semibold text-[#1a1a2e]">{contract.title}</h2>
            <div className="mt-1 flex items-center gap-2">
              <Badge className={STATUS_STYLE[contract.status] || STATUS_STYLE.draft}>{contract.status}</Badge>
              <span className="text-[11px] capitalize text-[#9a9aa6]">{contract.workflow_stage?.replace(/_/g, " ")}</span>
            </div>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <button onClick={runAiAnalysis} disabled={analyzing}
            className="flex items-center gap-1.5 rounded-xl border border-[#e0e0ea] px-4 py-2 text-[12px] text-[#4a4a5a] hover:bg-gray-50 disabled:opacity-50">
            {analyzing ? <Loader2 size={14} className="animate-spin" /> : <Brain size={14} />}
            {analyzing ? "Analyzing…" : "Run AI Analysis"}
          </button>
          <button onClick={() => navigate(`/editor/${contract._id}`)}
            className="flex items-center gap-1.5 rounded-xl bg-[#1a1a2e] px-4 py-2 text-[12px] font-medium text-white hover:bg-[#252545]">
            <FileText size={14} /> Open Editor
          </button>
        </div>
      </div>

      {/* Tabs */}
      <div className="mb-5 flex gap-1 rounded-xl bg-[#f0f0f5] p-1">
        {(["details", "workflow", "ai"] as const).map((t) => (
          <button key={t} onClick={() => setTab(t)}
            className={`rounded-lg px-4 py-2 text-[12px] font-medium transition ${tab === t ? "bg-white text-[#1a1a2e] shadow-sm" : "text-[#7b7b8a] hover:text-[#4a4a5a]"}`}>
            {t === "details" ? "Details" : t === "workflow" ? "Workflow" : "AI Analysis"}
          </button>
        ))}
      </div>

      {/* Details Tab */}
      {tab === "details" && (
        <div className="grid grid-cols-[1fr_0.8fr] gap-5">
          <div className="card p-5">
            <h3 className="mb-4 text-[13px] font-semibold text-[#1a1a2e]">Contract Information</h3>
            <div className="grid grid-cols-2 gap-4 text-[12px]">
              <div><p className="text-[#9a9aa6]">Type</p><p className="mt-0.5 font-medium capitalize text-[#3a3a4a]">{contract.contract_type.replace(/_/g, " ")}</p></div>
              <div><p className="text-[#9a9aa6]">Approval Type</p><p className="mt-0.5 font-medium capitalize text-[#3a3a4a]">{contract.approval_type.replace(/_/g, " ")}</p></div>
              <div className="flex items-start gap-2"><Calendar size={13} className="mt-0.5 text-[#9a9aa6]" /><div><p className="text-[#9a9aa6]">Start Date</p><p className="mt-0.5 font-medium text-[#3a3a4a]">{new Date(contract.start_date).toLocaleDateString()}</p></div></div>
              <div className="flex items-start gap-2"><Calendar size={13} className="mt-0.5 text-[#9a9aa6]" /><div><p className="text-[#9a9aa6]">End Date</p><p className="mt-0.5 font-medium text-[#3a3a4a]">{new Date(contract.end_date).toLocaleDateString()}</p></div></div>
              {contract.value != null && <div className="flex items-start gap-2"><DollarSign size={13} className="mt-0.5 text-[#9a9aa6]" /><div><p className="text-[#9a9aa6]">Value</p><p className="mt-0.5 font-medium text-[#3a3a4a]">${contract.value.toLocaleString()}</p></div></div>}
            </div>
            {contract.description && <div className="mt-4 border-t border-[#f0f0f5] pt-4"><p className="text-[11px] text-[#9a9aa6]">Description</p><p className="mt-1 text-[12px] text-[#3a3a4a]">{contract.description}</p></div>}
          </div>
          <div className="space-y-4">
            <div className="card p-5">
              <h3 className="mb-4 flex items-center gap-2 text-[13px] font-semibold text-[#1a1a2e]"><Users size={14} />Parties</h3>
              {contract.parties?.length > 0 ? (
                <div className="space-y-3">
                  {contract.parties.map((p, i) => (
                    <div key={i} className="rounded-xl bg-[#f7f7f8] p-3 text-[12px]">
                      <p className="font-medium text-[#3a3a4a]">{p.name}</p>
                      <p className="text-[#9a9aa6]">{p.role}{p.organization && ` - ${p.organization}`}</p>
                      <p className="text-[#7b7b8a]">{p.email}</p>
                    </div>
                  ))}
                </div>
              ) : <p className="text-[12px] text-[#9a9aa6]">No parties added</p>}
            </div>
            {approvals.length > 0 && (
              <div className="card p-5">
                <h3 className="mb-4 flex items-center gap-2 text-[13px] font-semibold text-[#1a1a2e]"><MessageSquare size={14} />Approvals</h3>
                <div className="space-y-3">
                  {approvals.map((a) => (
                    <div key={a._id} className="rounded-xl bg-[#f7f7f8] p-3 text-[12px]">
                      <div className="flex items-center justify-between">
                        <span className="font-medium capitalize text-[#3a3a4a]">{a.approval_type.replace(/_/g, " ")}</span>
                        <Badge className={a.status === "approved" ? "bg-green-100 text-green-700" : a.status === "rejected" ? "bg-red-100 text-red-700" : "bg-yellow-100 text-yellow-700"}>{a.status}</Badge>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {/* Workflow Tab */}
      {tab === "workflow" && (
        <div className="card p-6">
          {!workflow ? (
            <div>
              <p className="text-[13px] text-[#9a9aa6]">No workflow created yet.</p>
              <button onClick={async () => { setActing(true); try { await workflowsApi.create(contract._id); fetchData(); } catch { alert("Failed"); } finally { setActing(false); } }} disabled={acting}
                className="mt-3 rounded-xl bg-[#1a1a2e] px-4 py-2 text-[12px] font-medium text-white disabled:opacity-50">
                {acting ? "Creating…" : "Start Workflow"}
              </button>
            </div>
          ) : (
            <div>
              <div className="mb-5">
                <h3 className="text-[14px] font-semibold text-[#1a1a2e]">{workflow.name}</h3>
                <p className="mt-1 text-[11px] capitalize text-[#9a9aa6]">Status: {workflow.status} · Step {workflow.current_step} of {workflow.steps.length}</p>
              </div>
              <div className="space-y-0">
                {workflow.steps.map((step, i) => {
                  const Icon = step.status === "completed" ? CheckCircle2 : step.status === "in_progress" ? Clock : step.status === "rejected" ? XCircle : Circle;
                  const color = step.status === "completed" ? "text-green-500" : step.status === "in_progress" ? "text-blue-500" : step.status === "rejected" ? "text-red-500" : "text-gray-300";
                  const isCurrent = step.step_number === workflow.current_step;
                  return (
                    <div key={step.step_number} className="flex gap-4">
                      <div className="flex flex-col items-center">
                        <div className={`flex h-8 w-8 items-center justify-center rounded-full ${isCurrent ? "bg-blue-50 ring-2 ring-blue-200" : "bg-white"}`}><Icon size={18} className={color} /></div>
                        {i < workflow.steps.length - 1 && <div className="h-10 w-px bg-gray-200" />}
                      </div>
                      <div className="pb-6 pt-1">
                        <p className={`text-[13px] ${isCurrent ? "font-semibold text-[#1a1a2e]" : "text-[#4a4a5a]"}`}>{step.name}</p>
                        <p className="text-[11px] capitalize text-[#9a9aa6]">{step.step_type.replace(/_/g, " ")}</p>
                      </div>
                    </div>
                  );
                })}
              </div>
              {workflow.status === "active" && (
                <div className="mt-4 rounded-xl border border-[#ebebf0] p-4">
                  <textarea value={comment} onChange={(e) => setComment(e.target.value)} placeholder="Add a comment…" rows={2}
                    className="mb-3 w-full rounded-xl border border-[#e0e0ea] px-3 py-2 text-[12px] outline-none resize-none" />
                  <div className="flex gap-2">
                    <button onClick={async () => { setActing(true); try { await workflowsApi.advance(workflow._id, comment || undefined); setComment(""); fetchData(); } catch { alert("Failed"); } finally { setActing(false); } }} disabled={acting}
                      className="flex items-center gap-1 rounded-xl bg-green-600 px-4 py-2 text-[12px] font-medium text-white disabled:opacity-50">
                      {acting ? <Loader2 size={14} className="animate-spin" /> : <ChevronRight size={14} />} Complete & Advance
                    </button>
                    <button onClick={async () => { if (!comment.trim()) { alert("Comment required for rejection."); return; } setActing(true); try { await workflowsApi.reject(workflow._id, comment); setComment(""); fetchData(); } catch { alert("Failed"); } finally { setActing(false); } }} disabled={acting}
                      className="flex items-center gap-1 rounded-xl bg-red-500 px-4 py-2 text-[12px] font-medium text-white disabled:opacity-50">
                      <XCircle size={14} /> Reject
                    </button>
                  </div>
                </div>
              )}
            </div>
          )}
        </div>
      )}

      {/* AI Tab */}
      {tab === "ai" && (
        <div className="card p-6">
          {!analysis ? (
            <p className="text-[13px] text-[#9a9aa6]">No AI analysis yet. Click "Run AI Analysis" above.</p>
          ) : (
            <div className="grid grid-cols-2 gap-5">
              <div className="space-y-4">
                <div className="rounded-xl bg-[#f7f7f8] p-4">
                  <h4 className="mb-2 text-[12px] font-semibold text-[#1a1a2e]">Risk Score</h4>
                  <p className="text-[32px] font-bold text-[#1a1a2e]">{analysis.risk_score}</p>
                  <p className={`text-[12px] font-medium capitalize ${analysis.risk_level === "high" ? "text-red-500" : analysis.risk_level === "medium" ? "text-amber-500" : "text-emerald-500"}`}>{analysis.risk_level} Risk</p>
                </div>
                <div className="rounded-xl bg-[#f7f7f8] p-4">
                  <h4 className="mb-2 text-[12px] font-semibold text-[#1a1a2e]">Summary</h4>
                  <p className="text-[12px] leading-relaxed text-[#4a4a5a]">{analysis.summary}</p>
                </div>
              </div>
              <div className="space-y-4">
                {analysis.risk_factors?.length > 0 && (
                  <div className="rounded-xl bg-amber-50 p-4">
                    <h4 className="mb-2 text-[12px] font-semibold text-amber-800">Risk Factors</h4>
                    <ul className="space-y-1">{analysis.risk_factors.map((f, i) => <li key={i} className="text-[11px] text-amber-700">• {f}</li>)}</ul>
                  </div>
                )}
                {analysis.recommendations?.length > 0 && (
                  <div className="rounded-xl bg-green-50 p-4">
                    <h4 className="mb-2 text-[12px] font-semibold text-green-800">Recommendations</h4>
                    <ul className="space-y-1">{analysis.recommendations.map((r, i) => <li key={i} className="text-[11px] text-green-700">• {r}</li>)}</ul>
                  </div>
                )}
              </div>
            </div>
          )}
        </div>
      )}
    </AppLayout>
  );
}