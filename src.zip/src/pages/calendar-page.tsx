import { useState } from "react";
import { ChevronLeft, ChevronRight, Plus, AlertTriangle, RefreshCw, Clock, CheckCircle2, FileText } from "lucide-react";
import AppLayout from "@/components/layout/app-layout";

type EventType = "expiration" | "renewal" | "approval" | "milestone" | "review";
interface CalendarEvent { id: string; title: string; type: EventType; }

const EVENT_CONFIG = {
  expiration: { color: "text-red-600", bg: "bg-red-50 border-l-red-500", icon: AlertTriangle, label: "Expiration" },
  renewal: { color: "text-blue-600", bg: "bg-blue-50 border-l-blue-500", icon: RefreshCw, label: "Renewal" },
  approval: { color: "text-amber-600", bg: "bg-amber-50 border-l-amber-500", icon: Clock, label: "Approval" },
  milestone: { color: "text-green-600", bg: "bg-green-50 border-l-green-500", icon: CheckCircle2, label: "Milestone" },
  review: { color: "text-purple-600", bg: "bg-purple-50 border-l-purple-500", icon: FileText, label: "Review" },
};

const SAMPLE_EVENTS: Record<string, CalendarEvent[]> = {
  "2026-03-21": [{ id: "1", title: "Vendor Agreement Expiring", type: "expiration" }],
  "2026-03-24": [{ id: "2", title: "SaaS License Renewal", type: "renewal" }],
  "2026-03-27": [{ id: "3", title: "Payment Milestone", type: "milestone" }],
  "2026-03-28": [{ id: "4", title: "Final Approval Due", type: "approval" }],
  "2026-04-05": [{ id: "5", title: "Compliance Review", type: "review" }],
};

const WEEKDAYS = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
const MONTHS = ["January","February","March","April","May","June","July","August","September","October","November","December"];

export default function CalendarPage() {
  const [currentDate, setCurrentDate] = useState(new Date());
  const year = currentDate.getFullYear();
  const month = currentDate.getMonth();
  const today = new Date();

  const firstDay = new Date(year, month, 1).getDay();
  const daysInMonth = new Date(year, month + 1, 0).getDate();
  const prevDays = new Date(year, month, 0).getDate();

  const cells = [];
  for (let i = firstDay - 1; i >= 0; i--) cells.push({ day: prevDays - i, current: false });
  for (let d = 1; d <= daysInMonth; d++) {
    const key = `${year}-${String(month + 1).padStart(2, "0")}-${String(d).padStart(2, "0")}`;
    cells.push({ day: d, current: true, isToday: today.getDate() === d && today.getMonth() === month && today.getFullYear() === year, events: SAMPLE_EVENTS[key] || [] });
  }
  while (cells.length < 42) cells.push({ day: cells.length - firstDay - daysInMonth + 1, current: false });

  const navigate = (dir: -1 | 1) => setCurrentDate(new Date(year, month + dir, 1));

  return (
    <AppLayout title="Calendar">
      <div className="flex gap-6">
        <div className="flex-1">
          <div className="mb-4 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <h2 className="text-[18px] font-semibold text-[#1a1a2e]">{MONTHS[month]} {year}</h2>
              <div className="flex items-center gap-1">
                <button onClick={() => navigate(-1)} className="rounded-lg p-1.5 hover:bg-[#f0f0f5] transition"><ChevronLeft size={16} /></button>
                <button onClick={() => navigate(1)} className="rounded-lg p-1.5 hover:bg-[#f0f0f5] transition"><ChevronRight size={16} /></button>
                <button onClick={() => setCurrentDate(new Date())} className="ml-1 rounded-lg px-3 py-1 text-[11px] font-medium text-[#6b6b80] hover:bg-[#f0f0f5] transition">Today</button>
              </div>
            </div>
          </div>
          <div className="card overflow-hidden p-0">
            <div className="grid grid-cols-7 border-b border-[#f0f0f5]">
              {WEEKDAYS.map((d) => <div key={d} className="py-3 text-center text-[11px] font-semibold text-[#9a9aa6]">{d}</div>)}
            </div>
            <div className="grid grid-cols-7">
              {cells.map((cell, i) => (
                <div key={i} className={`min-h-[90px] border-b border-r border-[#f0f0f5] p-2 ${!cell.current ? "bg-[#fafafa]" : "bg-white"} ${"isToday" in cell && cell.isToday ? "ring-2 ring-inset ring-[#6366f1]" : ""}`}>
                  <div className={`mb-1 w-6 h-6 flex items-center justify-center rounded-full text-[12px] font-medium ${"isToday" in cell && cell.isToday ? "bg-[#6366f1] text-white" : cell.current ? "text-[#1a1a2e]" : "text-[#c0c0c8]"}`}>{cell.day}</div>
                  {"events" in cell && cell.events?.slice(0, 2).map((ev) => {
                    const cfg = EVENT_CONFIG[ev.type];
                    const Icon = cfg.icon;
                    return (
                      <div key={ev.id} className={`flex items-center gap-1 rounded px-1.5 py-0.5 text-[9px] border-l-2 mb-0.5 ${cfg.bg}`}>
                        <Icon size={9} className={cfg.color} />
                        <span className="truncate text-[#3a3a4a]">{ev.title}</span>
                      </div>
                    );
                  })}
                </div>
              ))}
            </div>
          </div>
        </div>

        <div className="w-[260px] shrink-0">
          <div className="card p-4">
            <div className="mb-4 flex items-center justify-between">
              <h3 className="text-[13px] font-semibold text-[#1a1a2e]">Upcoming Events</h3>
              <button className="flex items-center gap-1 rounded-lg bg-[#1a1a2e] px-2.5 py-1.5 text-[10px] font-medium text-white"><Plus size={11} />Add</button>
            </div>
            <div className="space-y-2">
              {Object.entries(SAMPLE_EVENTS).slice(0, 5).map(([date, events]) =>
                events.map((ev) => {
                  const cfg = EVENT_CONFIG[ev.type];
                  const Icon = cfg.icon;
                  return (
                    <div key={ev.id} className={`rounded-xl border-l-[3px] p-3 ${cfg.bg}`}>
                      <div className="flex items-center gap-1.5"><Icon size={12} className={cfg.color} /><span className={`text-[10px] font-semibold ${cfg.color}`}>{cfg.label}</span></div>
                      <p className="mt-1 text-[11px] font-medium text-[#1a1a2e]">{ev.title}</p>
                      <p className="mt-0.5 text-[10px] text-[#8a8a9a]">{new Date(date).toLocaleDateString("en-US", { month: "short", day: "numeric" })}</p>
                    </div>
                  );
                })
              )}
            </div>
          </div>
        </div>
      </div>
    </AppLayout>
  );
}