import { SignUp } from "@clerk/clerk-react";
import heroImg from "@/assets/hero.png";

export default function SignUpPage() {
  return (
    <div className="flex min-h-screen items-center justify-center bg-[#2a2a30] p-4">
      <div className="flex w-full max-w-[700px] overflow-hidden rounded-2xl bg-white shadow-2xl">
        <div className="flex flex-1 flex-col justify-center px-10 py-12">
          <h2 className="mb-8 text-[26px] font-bold text-[#1a1a2e]">Get Started Now</h2>
          <SignUp routing="hash" appearance={{
            elements: {
              rootBox: "w-full",
              card: "w-full shadow-none p-0",
              headerTitle: "hidden",
              headerSubtitle: "hidden",
              socialButtonsBlockButton: "border border-[#e0e0ea] rounded-xl text-[13px] h-11 font-medium",
              formButtonPrimary: "bg-[#2563eb] hover:bg-[#1d4ed8] rounded-xl h-11 text-[13px] font-semibold",
              formFieldInput: "rounded-xl border-[#e0e0ea] h-11 text-[13px]",
              formFieldLabel: "text-[12px] font-medium text-[#4a4a5a]",
              footerActionLink: "text-[#2563eb] font-semibold",
            },
          }} />
        </div>
        <div className="hidden w-[300px] shrink-0 overflow-hidden bg-[#eaeae5] sm:block">
          <img src={heroImg} alt="" className="h-full w-full object-cover" />
        </div>
      </div>
    </div>
  );
}