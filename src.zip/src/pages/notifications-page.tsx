import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import AppLayout from "@/components/layout/app-layout";
import { notificationsApi } from "@/services/api";
import type { Notification } from "@/types";
import { Bell, CheckCheck, FileText, AlertTriangle, Clock, RefreshCw, Loader2 } from "lucide-react";

const TYPE_ICONS: Record<string, any> = {
  approval_required: Clock, approval_decision: CheckCheck, contract_expiring: AlertTriangle,
  obligation_due: FileText, workflow_update: RefreshCw, system: Bell,
};
const TYPE_COLORS: Record<string, string> = {
  approval_required: "text-amber-500 bg-amber-50", approval_decision: "text-green-500 bg-green-50",
  contract_expiring: "text-red-500 bg-red-50", obligation_due: "text-blue-500 bg-blue-50",
  workflow_update: "text-purple-500 bg-purple-50", system: "text-gray-500 bg-gray-50",
};

export default function NotificationsPage() {
  const navigate = useNavigate();
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState<"all" | "unread">("all");

  const fetch = () => {
    setLoading(true);
    notificationsApi.list({ unread: filter === "unread" ? true : undefined, per_page: 50 })
      .then((res) => { const d = res.data; setNotifications(d.data || d || []); })
      .catch(() => {}).finally(() => setLoading(false));
  };

  useEffect(() => { fetch(); }, [filter]);

  const markAll = async () => { await notificationsApi.markAllRead().catch(() => {}); fetch(); };
  const markOne = async (id: string) => {
    await notificationsApi.markRead(id).catch(() => {});
    setNotifications((p) => p.map((n) => n._id === id ? { ...n, is_read: true } : n));
  };

  return (
    <AppLayout title="Notifications">
      <div className="card p-5">
        <div className="flex items-center justify-between mb-5">
          <div className="flex gap-1">
            {(["all", "unread"] as const).map((f) => (
              <button key={f} onClick={() => setFilter(f)}
                className={`rounded-xl px-4 py-2 text-[12px] font-medium capitalize transition ${filter === f ? "bg-[#1a1a2e] text-white" : "text-[#6b6b80] hover:bg-[#f5f5f9]"}`}>
                {f}
              </button>
            ))}
          </div>
          <button onClick={markAll} className="flex items-center gap-1.5 text-[12px] font-medium text-[#6366f1] hover:underline">
            <CheckCheck size={14} /> Mark all as read
          </button>
        </div>

        {loading ? (
          <div className="flex items-center justify-center py-12"><Loader2 className="h-5 w-5 animate-spin text-[#9a9aa6]" /></div>
        ) : notifications.length === 0 ? (
          <div className="py-12 text-center text-[13px] text-[#9a9aa6]">No notifications</div>
        ) : (
          <div className="space-y-1">
            {notifications.map((n) => {
              const Icon = TYPE_ICONS[n.notification_type] || Bell;
              const colors = TYPE_COLORS[n.notification_type] || TYPE_COLORS.system;
              return (
                <button key={n._id} onClick={() => { markOne(n._id); if (n.contract_id) navigate(`/contracts/${n.contract_id}`); }}
                  className={`flex w-full items-start gap-3 rounded-xl p-4 text-left transition ${n.is_read ? "hover:bg-[#fafafa]" : "bg-blue-50/30 hover:bg-blue-50/50"}`}>
                  <div className={`flex h-9 w-9 shrink-0 items-center justify-center rounded-xl ${colors}`}><Icon size={16} /></div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between">
                      <p className={`text-[13px] ${n.is_read ? "text-[#4a4a5a]" : "font-semibold text-[#1a1a2e]"}`}>{n.title}</p>
                      <span className="ml-2 shrink-0 text-[10px] text-[#9a9aa6]">{new Date(n.created_at).toLocaleDateString()}</span>
                    </div>
                    <p className="mt-0.5 truncate text-[11px] text-[#7b7b8a]">{n.message}</p>
                  </div>
                  {!n.is_read && <div className="mt-2 h-2 w-2 shrink-0 rounded-full bg-blue-500" />}
                </button>
              );
            })}
          </div>
        )}
      </div>
    </AppLayout>
  );
}
