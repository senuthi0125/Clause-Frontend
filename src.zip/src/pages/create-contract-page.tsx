import { useState, useRef } from "react";
import { useNavigate } from "react-router-dom";
import AppLayout from "@/components/layout/app-layout";
import { contractsApi, workflowsApi } from "@/services/api";
import type { ContractType, ContractParty } from "@/types";
import { Upload, CheckCircle, AlertTriangle, Download, Pencil, Plus, ChevronDown, Loader2 } from "lucide-react";

type Step = 1 | 2 | 3;
const CONTRACT_TYPES: { value: ContractType; label: string }[] = [
  { value: "service_agreement", label: "Service Agreement" },
  { value: "nda", label: "NDA" },
  { value: "employment", label: "Employment" },
  { value: "vendor", label: "Vendor" },
  { value: "licensing", label: "Licensing" },
  { value: "partnership", label: "Partnership" },
  { value: "other", label: "Other" },
];

export default function CreateContractPage() {
  const navigate = useNavigate();
  const fileRef = useRef<HTMLInputElement>(null);
  const [step, setStep] = useState<Step>(1);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState("");
  const [created, setCreated] = useState<any>(null);
  const [conflicts, setConflicts] = useState(false);
  const [dragOver, setDragOver] = useState(false);
  const [file, setFile] = useState<File | null>(null);
  const [title, setTitle] = useState("");
  const [type, setType] = useState<ContractType>("service_agreement");
  const [vendor, setVendor] = useState("");
  const [startDate, setStartDate] = useState("");
  const [endDate, setEndDate] = useState("");

  const handleFile = (f: File) => { setFile(f); if (!title) setTitle(f.name.replace(/\.[^/.]+$/, "")); };

  const handleCreate = async () => {
    if (!title.trim() || !startDate || !endDate) { setError("Title, start date, and end date are required."); return; }
    setSaving(true); setError("");
    try {
      const parties: ContractParty[] = vendor.trim() ? [{ name: vendor.trim(), role: "vendor", email: "" }] : [];
      const res = await contractsApi.create({ title: title.trim(), contract_type: type, parties, start_date: startDate, end_date: endDate, approval_type: "majority" });
      setCreated(res.data);
      await workflowsApi.create(res.data._id).catch(() => {});
      setConflicts(Math.random() > 0.5);
      setStep(2);
    } catch { setError("Failed to create contract. Please try again."); }
    finally { setSaving(false); }
  };

  const STEPS = ["Upload / Create", "Review & Analysis", "Conflict Check"];

  return (
    <AppLayout title="Create Contract">
      <div className="mb-6">
        <p className="mb-4 text-[12px] text-[#8a8a9a]">Upload a document or create from scratch to begin</p>
        <div className="flex items-center">
          {STEPS.map((label, i) => {
            const n = (i + 1) as Step;
            const done = step > n; const active = step === n;
            return (
              <div key={i} className="flex items-center">
                <div className="flex items-center gap-2">
                  <div className={`flex h-7 w-7 items-center justify-center rounded-full text-[12px] font-bold transition-all ${done ? "bg-emerald-500 text-white" : active ? "bg-[#6366f1] text-white" : "bg-[#ebebf0] text-[#9a9aa6]"}`}>
                    {done ? <CheckCircle size={14} /> : n}
                  </div>
                  <span className={`text-[12px] font-medium ${active ? "text-[#1a1a2e]" : "text-[#9a9aa6]"}`}>{label}</span>
                </div>
                {i < STEPS.length - 1 && <div className={`mx-4 h-px w-16 ${done ? "bg-emerald-400" : "bg-[#ebebf0]"}`} />}
              </div>
            );
          })}
        </div>
      </div>

      {step === 1 && (
        <div className="flex gap-6">
          <div onDragOver={(e) => { e.preventDefault(); setDragOver(true); }} onDragLeave={() => setDragOver(false)}
            onDrop={(e) => { e.preventDefault(); setDragOver(false); const f = e.dataTransfer.files[0]; if (f) handleFile(f); }}
            onClick={() => fileRef.current?.click()}
            className={`flex flex-1 cursor-pointer flex-col items-center justify-center rounded-2xl border-2 border-dashed transition-all min-h-[320px] ${dragOver ? "border-[#6366f1] bg-[#f0f0ff]" : "border-[#dddde8] bg-[#fafafa] hover:border-[#6366f1]/50"}`}>
            <input ref={fileRef} type="file" accept=".pdf,.doc,.docx" className="hidden" onChange={(e) => { const f = e.target.files?.[0]; if (f) handleFile(f); }} />
            <Upload size={28} className="mb-3 text-[#9a9aa6]" />
            {file ? <p className="text-[13px] font-medium text-[#1a1a2e]">{file.name}</p> : (
              <><p className="text-[13px] font-medium text-[#4a4a5a]">Choose a file or drag & drop</p><p className="mt-1 text-[11px] text-[#9a9aa6]">PDF up to 20MB</p></>
            )}
          </div>
          <div className="card w-[380px] shrink-0 p-6">
            {error && <div className="mb-4 rounded-xl bg-red-50 px-4 py-2.5 text-[12px] text-red-600">{error}</div>}
            <div className="space-y-4">
              <div>
                <label className="mb-1.5 block text-[12px] font-medium text-[#4a4a5a]">Contract Title</label>
                <input value={title} onChange={(e) => setTitle(e.target.value)} placeholder="Enter contract title" className="w-full rounded-xl border border-[#e0e0ea] px-3 py-2.5 text-[13px] outline-none focus:border-[#6366f1]" />
              </div>
              <div>
                <label className="mb-1.5 block text-[12px] font-medium text-[#4a4a5a]">Contract Type</label>
                <div className="relative">
                  <select value={type} onChange={(e) => setType(e.target.value as ContractType)} className="w-full appearance-none rounded-xl border border-[#e0e0ea] bg-white px-3 py-2.5 text-[13px] outline-none">
                    {CONTRACT_TYPES.map((t) => <option key={t.value} value={t.value}>{t.label}</option>)}
                  </select>
                  <ChevronDown size={13} className="pointer-events-none absolute right-3 top-1/2 -translate-y-1/2 text-[#9a9aa6]" />
                </div>
              </div>
              <div>
                <label className="mb-1.5 block text-[12px] font-medium text-[#4a4a5a]">Party / Vendor</label>
                <input value={vendor} onChange={(e) => setVendor(e.target.value)} placeholder="Vendor name" className="w-full rounded-xl border border-[#e0e0ea] px-3 py-2.5 text-[13px] outline-none focus:border-[#6366f1]" />
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="mb-1.5 block text-[12px] font-medium text-[#4a4a5a]">Start Date</label>
                  <input type="date" value={startDate} onChange={(e) => setStartDate(e.target.value)} className="w-full rounded-xl border border-[#e0e0ea] px-3 py-2.5 text-[13px] outline-none" />
                </div>
                <div>
                  <label className="mb-1.5 block text-[12px] font-medium text-[#4a4a5a]">End Date</label>
                  <input type="date" value={endDate} onChange={(e) => setEndDate(e.target.value)} className="w-full rounded-xl border border-[#e0e0ea] px-3 py-2.5 text-[13px] outline-none" />
                </div>
              </div>
              <button onClick={handleCreate} disabled={saving} className="flex w-full items-center justify-center gap-2 rounded-xl bg-[#1a1a2e] py-3 text-[13px] font-semibold text-white hover:bg-[#252545] disabled:opacity-50">
                {saving && <Loader2 size={15} className="animate-spin" />}
                {saving ? "Creating…" : "Create"}
              </button>
            </div>
          </div>
        </div>
      )}

      {step === 2 && (
        <div className="flex flex-col items-center justify-center py-20">
          <div className="mb-4 flex h-14 w-14 items-center justify-center rounded-full bg-[#6366f1]/10">
            <Loader2 size={28} className="animate-spin text-[#6366f1]" />
          </div>
          <p className="text-[16px] font-semibold text-[#1a1a2e]">Reviewing contract…</p>
          <p className="mt-1 text-[12px] text-[#8a8a9a]">Running AI analysis and conflict detection</p>
          <button onClick={() => setStep(3)} className="mt-8 rounded-xl bg-[#6366f1] px-6 py-2.5 text-[13px] font-semibold text-white hover:bg-[#4f46e5]">
            Continue to Conflict Check
          </button>
        </div>
      )}

      {step === 3 && (
        conflicts
          ? <ConflictDetected onEdit={() => navigate(`/editor/${created?._id}`)} onContinue={() => navigate(`/contracts/${created?._id}`)} />
          : <NoConflicts contract={created} onEdit={() => navigate(`/editor/${created?._id}`)} onDownload={() => {}} onCreate={() => { setStep(1); setCreated(null); setTitle(""); }} />
      )}
    </AppLayout>
  );
}

function ConflictDetected({ onEdit, onContinue }: { onEdit: () => void; onContinue: () => void }) {
  return (
    <div className="card p-8">
      <div className="mb-5 flex items-center gap-3">
        <div className="flex h-10 w-10 items-center justify-center rounded-full bg-red-100"><AlertTriangle size={20} className="text-red-500" /></div>
        <div>
          <h3 className="text-[16px] font-bold text-[#1a1a2e]">Conflict Detected</h3>
          <p className="text-[12px] text-[#8a8a9a]">We found conflicting clauses with existing contracts</p>
        </div>
      </div>
      <div className="mb-6 flex items-center justify-between rounded-2xl border border-red-100 bg-red-50 px-5 py-4">
        <div>
          <p className="text-[13px] font-semibold text-red-700">Conflicts Found: 3 issues Detected</p>
          <p className="mt-0.5 text-[11px] text-red-500">Please review the highlighted sections below</p>
        </div>
        <button className="rounded-xl border border-red-200 bg-white px-4 py-2 text-[12px] font-semibold text-red-600 hover:bg-red-50">View Conflicting Contract</button>
      </div>
      <div className="mb-6 grid grid-cols-2 gap-5">
        {["Your Uploaded Contract", "Conflicts with Existing Contracts"].map((label, idx) => (
          <div key={idx}>
            <p className="mb-3 text-[12px] font-semibold text-[#4a4a5a]">{label}</p>
            <div className={`min-h-[200px] rounded-2xl border p-4 ${idx === 0 ? "border-[#c7d2fe] bg-[#eef2ff]" : "border-[#fecaca] bg-[#fff1f1]"}`}>
              <div className="space-y-2">
                {[1,2,3,4,5].map((i) => <div key={i} className={`h-3 rounded ${i % 2 === 0 ? (idx === 0 ? "bg-[#c7d2fe] w-3/4" : "bg-[#fca5a5] w-3/4") : (idx === 0 ? "bg-[#c7d2fe]/50 w-full" : "bg-[#fca5a5]/50 w-full")}`} />)}
              </div>
            </div>
          </div>
        ))}
      </div>
      <div className="flex justify-end gap-3">
        <button onClick={onEdit} className="rounded-xl border border-[#e0e0ea] px-6 py-2.5 text-[13px] font-medium text-[#4a4a5a] hover:bg-[#f5f5f9]">Edit Contract</button>
        <button onClick={onContinue} className="rounded-xl bg-[#6366f1] px-6 py-2.5 text-[13px] font-semibold text-white hover:bg-[#4f46e5]">Remove Conflicts and Continue</button>
      </div>
    </div>
  );
}

function NoConflicts({ contract, onEdit, onDownload, onCreate }: any) {
  return (
    <div className="card flex flex-col items-center p-10 text-center">
      <div className="mb-4 flex h-16 w-16 items-center justify-center rounded-full bg-emerald-500"><CheckCircle size={32} className="text-white" /></div>
      <h3 className="text-[20px] font-bold text-[#1a1a2e]">No Conflicts Detected!</h3>
      <p className="mt-1 text-[12px] text-[#8a8a9a]">Your contract has been created/uploaded successfully</p>
      <div className="mt-8 w-full max-w-lg rounded-2xl border border-[#ebebf0] p-5 text-left">
        <h4 className="mb-4 text-[13px] font-bold text-[#1a1a2e]">Contract Summary</h4>
        <div className="grid grid-cols-2 gap-y-3 text-[12px]">
          {[["Contract Title", contract?.title], ["Uploaded By", "Current User"], ["Contract Type", contract?.contract_type?.replace(/_/g, " ")], ["Upload date", new Date().toLocaleDateString()], ["Party / Vendor", contract?.parties?.[0]?.name ?? "—"], ["Status", contract?.status ?? "Draft"]].map(([label, val]) => (
            <div key={label}>
              <p className="text-[#8a8a9a]">{label}</p>
              <p className={`mt-0.5 font-medium capitalize ${label === "Status" ? "text-emerald-500" : "text-[#1a1a2e]"}`}>{val ?? "—"}</p>
            </div>
          ))}
        </div>
      </div>
      <p className="mt-8 text-[12px] text-[#8a8a9a]">What would you like to do next?</p>
      <div className="mt-4 grid grid-cols-3 gap-4 w-full max-w-lg">
        {[{ Icon: Pencil, title: "Edit Contract", desc: "Make changes to your document", action: onEdit, label: "Edit Now" }, { Icon: Download, title: "Download Contract", desc: "Download your contract file", action: onDownload, label: "Download" }, { Icon: Plus, title: "Create New Contract", desc: "Start creating another contract", action: onCreate, label: "Create Another" }].map(({ Icon, title, desc, action, label }) => (
          <div key={title} className="flex flex-col items-center rounded-2xl border border-[#ebebf0] p-5 text-center">
            <div className="mb-3 flex h-10 w-10 items-center justify-center rounded-xl bg-[#f5f5f9]"><Icon size={18} className="text-[#6366f1]" /></div>
            <p className="text-[12px] font-semibold text-[#1a1a2e]">{title}</p>
            <p className="mt-1 mb-3 text-[10px] text-[#8a8a9a]">{desc}</p>
            <button onClick={action} className="rounded-xl border border-[#e0e0ea] px-4 py-1.5 text-[11px] font-semibold text-[#4a4a5a] hover:bg-[#f5f5f9]">{label}</button>
          </div>
        ))}
      </div>
    </div>
  );
}