import { useEffect, useState } from "react";
import AppLayout from "@/components/layout/app-layout";
import StatCard from "@/components/dashboard/stat-card";
import UpcomingDocuments from "@/components/dashboard/upcoming-documents";
import AiAnalysisCard from "@/components/dashboard/ai-analysis-card";
import ApprovalsChart from "@/components/dashboard/approvals-chart";
import { dashboardApi } from "@/services/api";
import type { DashboardStats, ChartDataItem, Contract } from "@/types";

export default function DashboardPage() {
  const [stats, setStats] = useState<DashboardStats | null>(null);
  const [byStatus, setByStatus] = useState<ChartDataItem[]>([]);
  const [monthlyStats, setMonthlyStats] = useState<ChartDataItem[]>([]);
  const [expiring, setExpiring] = useState<Contract[]>([]);

  useEffect(() => {
    dashboardApi.getStats().then((r) => setStats(r.data)).catch(() => {});
    dashboardApi.getContractsByStatus().then((r) => setByStatus(r.data)).catch(() => {});
    dashboardApi.getMonthlyStats().then((r) => setMonthlyStats(r.data)).catch(() => {});
    dashboardApi.getExpiringSoon().then((r) => setExpiring(r.data)).catch(() => {});
  }, []);

  const statCards = [
    { title: "Total Contracts", value: stats?.total_contracts?.toLocaleString() ?? "—", change: "11.01%", positive: true },
    { title: "Active Contracts", value: stats?.active_contracts?.toLocaleString() ?? "—", change: "0.03%", positive: false },
    { title: "Pending Approvals", value: stats?.pending_approvals?.toString() ?? "—", change: "15.03%", positive: true },
    { title: "Expiring Soon", value: stats?.expiring_soon?.toString() ?? "—", change: "6.08%", positive: false },
  ];

  return (
    <AppLayout title="Dashboard">
      <div className="grid grid-cols-4 gap-4">
        {statCards.map((s) => <StatCard key={s.title} {...s} />)}
      </div>
      <div className="mt-5 grid grid-cols-[1.2fr_0.9fr] gap-5">
        <UpcomingDocuments contracts={expiring} />
        <AiAnalysisCard byStatus={byStatus} />
      </div>
      <div className="mt-5">
        <ApprovalsChart monthlyStats={monthlyStats} />
      </div>
    </AppLayout>
  );
}