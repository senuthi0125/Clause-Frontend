import { useEffect, useState } from "react";
import { Search, Plus, Loader2, Trash2, FileText } from "lucide-react";
import { useNavigate } from "react-router-dom";
import AppLayout from "@/components/layout/app-layout";
import { templatesApi } from "@/services/api";
import type { Template } from "@/types";

const TYPE_FILTERS = [
  { value: "", label: "All" },
  { value: "service_agreement", label: "Service Agreement" },
  { value: "nda", label: "NDA" },
  { value: "employment", label: "Employment" },
  { value: "vendor", label: "Vendor" },
  { value: "licensing", label: "Licensing" },
  { value: "partnership", label: "Partnership" },
];

export default function TemplatesPage() {
  const navigate = useNavigate();
  const [templates, setTemplates] = useState<Template[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState("");
  const [typeFilter, setTypeFilter] = useState("");

  const fetchTemplates = () => {
    setLoading(true);
    templatesApi.list({ search: search || undefined, contract_type: typeFilter || undefined })
      .then((res) => { const d = res.data; setTemplates(d.data || d || []); })
      .catch(() => {}).finally(() => setLoading(false));
  };

  useEffect(() => { fetchTemplates(); }, [typeFilter]);

  return (
    <AppLayout title="Contract Templates">
      <div className="mb-5 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="flex h-10 items-center gap-2 rounded-xl bg-white border border-[#ebebf0] px-3 w-64">
            <Search size={13} className="text-[#9a9aa6]" />
            <input value={search} onChange={(e) => setSearch(e.target.value)} onKeyDown={(e) => e.key === "Enter" && fetchTemplates()}
              placeholder="Search templates…" className="flex-1 bg-transparent text-[12px] outline-none placeholder:text-[#9a9aa6]" />
          </div>
          <div className="flex gap-1">
            {TYPE_FILTERS.map((t) => (
              <button key={t.value} onClick={() => setTypeFilter(t.value)}
                className={`rounded-full px-3 py-1.5 text-[11px] font-medium transition ${typeFilter === t.value ? "bg-[#1a1a2e] text-white" : "bg-white border border-[#ebebf0] text-[#6b6b80] hover:border-[#9a9aa6]"}`}>
                {t.label}
              </button>
            ))}
          </div>
        </div>
        <button className="flex items-center gap-1.5 rounded-xl bg-[#1a1a2e] px-4 py-2 text-[12px] font-medium text-white hover:bg-[#252545]">
          <Plus size={13} /> New Template
        </button>
      </div>

      {loading ? (
        <div className="flex items-center justify-center py-20"><Loader2 className="h-6 w-6 animate-spin text-[#9a9aa6]" /></div>
      ) : templates.length === 0 ? (
        <div className="py-20 text-center">
          <FileText size={40} className="mx-auto mb-3 text-[#d0d0da]" />
          <p className="text-[13px] text-[#9a9aa6]">No templates found</p>
        </div>
      ) : (
        <div className="grid grid-cols-3 gap-5">
          {templates.map((t) => (
            <div key={t._id} className="card group cursor-pointer p-5 hover:shadow-md transition-shadow">
              <div className="mb-4 flex h-32 items-center justify-center rounded-xl bg-[#f5f5f9]">
                <FileText size={36} className="text-[#c0c0d0]" />
              </div>
              <div className="flex items-start justify-between">
                <div>
                  <p className="text-[13px] font-semibold text-[#1a1a2e]">{t.name}</p>
                  <p className="mt-0.5 text-[11px] capitalize text-[#8a8a9a]">{t.contract_type.replace(/_/g, " ")}</p>
                </div>
                <button onClick={(e) => { e.stopPropagation(); if (confirm("Delete template?")) templatesApi.delete(t._id).then(fetchTemplates); }}
                  className="opacity-0 group-hover:opacity-100 text-red-400 hover:text-red-600 transition-opacity">
                  <Trash2 size={14} />
                </button>
              </div>
              {t.description && <p className="mt-2 text-[11px] text-[#8a8a9a] line-clamp-2">{t.description}</p>}
              <button onClick={() => navigate(`/contracts/new`)}
                className="mt-3 w-full rounded-xl border border-[#e0e0ea] py-2 text-[11px] font-medium text-[#4a4a5a] hover:bg-[#f5f5f9] transition">
                Use Template
              </button>
            </div>
          ))}
        </div>
      )}
    </AppLayout>
  );
}