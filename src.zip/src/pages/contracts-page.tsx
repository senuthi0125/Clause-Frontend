import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import AppLayout from "@/components/layout/app-layout";
import { Checkbox } from "@/components/ui/checkbox";
import { Badge } from "@/components/ui/badge";
import { contractsApi } from "@/services/api";
import type { Contract, ContractStatus } from "@/types";
import { Search, Plus, Pencil, Trash2, ChevronLeft, ChevronRight } from "lucide-react";

type Tab = "all" | "active" | "expire";

const STATUS_STYLE: Record<ContractStatus, string> = {
  active: "bg-emerald-50 text-emerald-600",
  draft: "bg-gray-100 text-gray-500",
  expired: "bg-red-50 text-red-600",
  terminated: "bg-orange-50 text-orange-600",
  renewed: "bg-blue-50 text-blue-600",
};

const STATUS_LABEL: Record<ContractStatus, string> = {
  active: "Success",
  draft: "Draft",
  expired: "Failed",
  terminated: "Terminated",
  renewed: "Renewed",
};

const TYPE_LABELS: Record<string, string> = {
  service_agreement: "Service Agreement",
  nda: "NDA",
  employment: "Employment",
  vendor: "Vendor",
  licensing: "Licensing",
  partnership: "Partnership",
  other: "Other",
};

export default function ContractsPage() {
  const navigate = useNavigate();
  const [tab, setTab] = useState<Tab>("all");
  const [contracts, setContracts] = useState<Contract[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState("");
  const [page, setPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const [selected, setSelected] = useState<Set<string>>(new Set());

  const fetchContracts = () => {
    setLoading(true);
    contractsApi.list({
      search: search || undefined,
      status: tab === "active" ? "active" : tab === "expire" ? "expired" : undefined,
      page,
      per_page: 15,
    })
      .then((res) => {
        const d = res.data;
        setContracts(d.data || d || []);
        setTotalPages(d.total_pages || 1);
      })
      .catch(() => {})
      .finally(() => setLoading(false));
  };

  useEffect(() => { fetchContracts(); }, [tab, page]);

  const toggle = (id: string) =>
    setSelected((p) => { const n = new Set(p); n.has(id) ? n.delete(id) : n.add(id); return n; });

  const deleteSelected = async () => {
    if (!confirm(`Delete ${selected.size} contract(s)?`)) return;
    for (const id of selected) await contractsApi.delete(id).catch(() => {});
    setSelected(new Set());
    fetchContracts();
  };

  const TABS: { key: Tab; label: string }[] = [
    { key: "all", label: "All Contracts" },
    { key: "active", label: "Active" },
    { key: "expire", label: "Expire" },
  ];

  return (
    <AppLayout title="Contracts">
      <div className="card overflow-hidden p-0">
        {/* Toolbar */}
        <div className="flex items-center justify-between border-b border-[#f0f0f5] px-5 py-3">
          <div className="flex items-center gap-1">
            {TABS.map((t) => (
              <button key={t.key} onClick={() => { setTab(t.key); setPage(1); }}
                className={`rounded-lg px-4 py-2 text-[12px] font-medium transition ${tab === t.key ? "bg-[#1a1a2e] text-white" : "text-[#6b6b80] hover:bg-[#f5f5f9]"}`}>
                {t.label}
              </button>
            ))}
            <button onClick={() => navigate("/contracts/new")}
              className="rounded-lg px-4 py-2 text-[12px] font-medium text-[#6b6b80] transition hover:bg-[#f5f5f9]">
              Create
            </button>
            <button onClick={() => navigate("/templates")}
              className="rounded-lg px-4 py-2 text-[12px] font-medium text-[#6b6b80] transition hover:bg-[#f5f5f9]">
              Templates
            </button>
          </div>
          <div className="flex items-center gap-2">
            <div className="flex h-9 items-center gap-2 rounded-xl bg-[#f5f5f9] px-3">
              <Search size={13} className="text-[#9a9aa6]" />
              <input value={search} onChange={(e) => setSearch(e.target.value)}
                onKeyDown={(e) => e.key === "Enter" && fetchContracts()}
                placeholder="Search for Keywords"
                className="w-44 bg-transparent text-[12px] outline-none placeholder:text-[#9a9aa6]" />
            </div>
            {selected.size > 0 && (
              <button onClick={deleteSelected} className="flex items-center gap-1 rounded-xl px-3 py-2 text-[12px] text-red-500 hover:bg-red-50">
                <Trash2 size={13} /> Delete ({selected.size})
              </button>
            )}
            <button onClick={() => navigate("/contracts/new")}
              className="flex items-center gap-1.5 rounded-xl bg-[#1a1a2e] px-4 py-2 text-[12px] font-medium text-white hover:bg-[#252545]">
              <Plus size={13} /> New Contract
            </button>
          </div>
        </div>

        {/* Table */}
        <div className="overflow-x-auto">
          {loading ? (
            <div className="py-16 text-center text-[13px] text-[#9a9aa6]">Loading…</div>
          ) : contracts.length === 0 ? (
            <div className="py-16 text-center">
              <p className="text-[13px] text-[#9a9aa6]">No contracts found</p>
              <button onClick={() => navigate("/contracts/new")} className="mt-2 text-[12px] font-semibold text-[#6366f1] hover:underline">
                Create your first contract
              </button>
            </div>
          ) : (
            <table className="w-full text-left">
              <thead className="border-b border-[#f0f0f5] bg-[#fafafa]">
                <tr>
                  {["", "Contract Name", "Date", "Status", "Type", "Vendor", "Action"].map((h) => (
                    <th key={h} className="px-4 py-3 text-[10px] font-semibold uppercase tracking-wider text-[#9a9aa6]">
                      {h === "" ? <Checkbox /> : h}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {contracts.map((c) => (
                  <tr key={c._id} onClick={() => navigate(`/contracts/${c._id}`)}
                    className="cursor-pointer border-b border-[#f8f8fb] transition hover:bg-[#fafafa]">
                    <td className="px-4 py-3.5" onClick={(e) => e.stopPropagation()}>
                      <Checkbox checked={selected.has(c._id)} onCheckedChange={() => toggle(c._id)} />
                    </td>
                    <td className="px-4 py-3.5 text-[13px] font-medium text-[#1a1a2e]">{c.title}</td>
                    <td className="px-4 py-3.5 text-[12px] text-[#7b7b8a]">
                      {c.start_date ? new Date(c.start_date).toLocaleDateString("en-US", { month: "long", day: "2-digit", year: "numeric" }) : "—"}
                    </td>
                    <td className="px-4 py-3.5">
                      <Badge className={STATUS_STYLE[c.status]}>{STATUS_LABEL[c.status] ?? c.status}</Badge>
                    </td>
                    <td className="px-4 py-3.5 text-[12px] text-[#7b7b8a]">{TYPE_LABELS[c.contract_type] ?? c.contract_type}</td>
                    <td className="px-4 py-3.5 text-[12px] text-[#7b7b8a]">{c.parties?.[0]?.email ?? "—"}</td>
                    <td className="px-4 py-3.5" onClick={(e) => e.stopPropagation()}>
                      <div className="flex items-center gap-3">
                        <button onClick={() => navigate(`/editor/${c._id}`)} className="text-[#6366f1] hover:text-[#4f46e5]"><Pencil size={14} /></button>
                        <button onClick={() => { if (confirm("Delete?")) contractsApi.delete(c._id).then(() => fetchContracts()); }} className="text-red-400 hover:text-red-600"><Trash2 size={14} /></button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>

        {totalPages > 1 && (
          <div className="flex items-center justify-center gap-3 border-t border-[#f0f0f5] py-4">
            <button onClick={() => setPage((p) => Math.max(1, p - 1))} disabled={page <= 1} className="rounded-xl border border-[#e0e0ea] p-2 disabled:opacity-30 hover:bg-[#f5f5f9]"><ChevronLeft size={14} /></button>
            <span className="text-[12px] text-[#7b7b8a]">Page {page} of {totalPages}</span>
            <button onClick={() => setPage((p) => Math.min(totalPages, p + 1))} disabled={page >= totalPages} className="rounded-xl border border-[#e0e0ea] p-2 disabled:opacity-30 hover:bg-[#f5f5f9]"><ChevronRight size={14} /></button>
          </div>
        )}
      </div>
    </AppLayout>
  );
}