interface StatCardProps {
  title: string;
  value: string;
  change?: string;
  positive?: boolean;
}

export default function StatCard({ title, value, change, positive = true }: StatCardProps) {
  return (
    <div className="card p-5">
      <p className="text-[11px] font-medium uppercase tracking-wide text-[#9a9aa6]">{title}</p>
      <div className="mt-2.5 flex items-end justify-between">
        <p className="text-[28px] font-bold leading-none text-[#1a1a2e]">{value}</p>
        {change && (
          <span className={`mb-0.5 flex items-center gap-0.5 text-[11px] font-semibold ${positive ? "text-emerald-500" : "text-red-500"}`}>
            {positive ? "↑" : "↓"} {change}
          </span>
        )}
      </div>
    </div>
  );
}