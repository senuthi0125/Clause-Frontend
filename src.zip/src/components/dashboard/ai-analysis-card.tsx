import { PieChart, Pie, Cell, ResponsiveContainer } from "recharts";
import type { ChartDataItem } from "@/types";

export default function AiAnalysisCard({
  byStatus,
}: {
  riskSummary?: { high: number; medium: number; low: number };
  byStatus: ChartDataItem[];
}) {
  const orderData = [
    { name: "Afternoon", value: 40, color: "#6366f1" },
    { name: "Evening", value: 32, color: "#a5b4fc" },
    { name: "Morning", value: 28, color: "#c7d2fe" },
  ];

  return (
    <div className="card p-5">
      <div className="mb-1 flex items-center justify-between">
        <h3 className="text-[13px] font-semibold text-[#1a1a2e]">Order Time</h3>
        <button className="text-[11px] font-medium text-[#6366f1] hover:underline">View Report</button>
      </div>
      <p className="mb-4 text-[11px] text-[#9a9aa6]">From 1–6 Dec, 2020</p>
      <div className="relative flex justify-center">
        <ResponsiveContainer width={200} height={200}>
          <PieChart>
            <Pie data={orderData} cx="50%" cy="50%" innerRadius={52} outerRadius={78} dataKey="value" stroke="none">
              {orderData.map((entry, i) => <Cell key={i} fill={entry.color} />)}
            </Pie>
          </PieChart>
        </ResponsiveContainer>
        <div className="absolute right-0 top-6 rounded-xl bg-[#1a1a2e] px-3 py-2 text-white shadow-lg">
          <p className="text-[10px] font-medium text-[#a5b4fc]">Afternoon</p>
          <p className="text-[9px] text-[#7070a0]">1pm – 4pm</p>
          <p className="mt-1 text-[14px] font-bold">1,890 orders</p>
        </div>
      </div>
      <div className="mt-2 flex justify-center gap-5">
        {orderData.map((d) => (
          <div key={d.name} className="flex items-center gap-1.5">
            <span className="h-2 w-2 rounded-full" style={{ background: d.color }} />
            <span className="text-[10px] text-[#6b6b80]">{d.name} {d.value}%</span>
          </div>
        ))}
      </div>
    </div>
  );
}