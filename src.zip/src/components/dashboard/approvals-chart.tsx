import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid } from "recharts";
import type { ChartDataItem } from "@/types";

const FALLBACK = ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"]
  .map((name) => ({ name, value: Math.floor(Math.random() * 22000 + 4000) }));

export default function ApprovalsChart({ monthlyStats }: { monthlyStats: ChartDataItem[] }) {
  const data = monthlyStats.length > 0 ? monthlyStats : FALLBACK;
  return (
    <div className="card p-5">
      <h3 className="mb-5 text-[13px] font-semibold text-[#1a1a2e]">Monthly Contract Approvals</h3>
      <ResponsiveContainer width="100%" height={210}>
        <BarChart data={data} barSize={20} barCategoryGap="30%">
          <CartesianGrid vertical={false} stroke="#f0f0f6" />
          <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{ fontSize: 11, fill: "#9a9aa6" }} />
          <YAxis axisLine={false} tickLine={false} tick={{ fontSize: 10, fill: "#9a9aa6" }} tickFormatter={(v) => `${(v / 1000).toFixed(0)}k`} />
          <Tooltip contentStyle={{ borderRadius: 10, border: "none", boxShadow: "0 4px 24px rgba(0,0,0,0.08)", fontSize: 12 }} cursor={{ fill: "#f5f5fa" }} />
          <Bar dataKey="value" fill="#a5b4fc" radius={[5, 5, 0, 0]} />
        </BarChart>
      </ResponsiveContainer>
    </div>
  );
}