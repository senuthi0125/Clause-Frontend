import { useNavigate } from "react-router-dom";
import type { Contract } from "@/types";

const DOTS = ["bg-yellow-400", "bg-blue-400", "bg-purple-400", "bg-green-400", "bg-red-400"];
const FALLBACK = [
  "Vendor Agreement Renewal due next week",
  "Software License Agreement expires this Friday",
  "Service Level Agreement (SLA) revision due Thursday",
  "Employment Contract updates due next Monday",
  "Maintenance Contract renewal reminder",
];

export default function UpcomingDocuments({ contracts }: { contracts: Contract[] }) {
  const navigate = useNavigate();
  const items = contracts.length > 0
    ? contracts.map((c) => `${c.title} — expires ${new Date(c.end_date).toLocaleDateString()}`)
    : FALLBACK;

  return (
    <div className="card p-5">
      <h3 className="mb-4 text-[13px] font-semibold text-[#1a1a2e]">Upcoming and Due Documents</h3>
      <ul className="space-y-3">
        {items.map((text, i) => (
          <li key={i} className="flex items-start gap-2.5">
            <span className={`mt-1.5 h-2 w-2 shrink-0 rounded-full ${DOTS[i % DOTS.length]}`} />
            <span className="text-[12px] leading-relaxed text-[#4a4a5a]">{text}</span>
          </li>
        ))}
      </ul>
      <button onClick={() => navigate("/contracts")}
        className="mt-4 text-[11px] font-semibold text-[#6366f1] transition hover:underline">
        View all contracts →
      </button>
    </div>
  );
}