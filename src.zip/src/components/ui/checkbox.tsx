import { cn } from "@/lib/utils";
import { Check } from "lucide-react";

interface CheckboxProps {
  checked?: boolean;
  onCheckedChange?: (checked: boolean) => void;
  className?: string;
  disabled?: boolean;
}

export function Checkbox({ checked, onCheckedChange, className, disabled }: CheckboxProps) {
  return (
    <button
      type="button"
      role="checkbox"
      aria-checked={checked}
      disabled={disabled}
      onClick={() => onCheckedChange?.(!checked)}
      className={cn(
        "flex h-4 w-4 shrink-0 items-center justify-center rounded border transition-all",
        checked ? "border-[#6366f1] bg-[#6366f1]" : "border-[#d0d0da] bg-white hover:border-[#6366f1]",
        disabled && "opacity-40 cursor-not-allowed",
        className
      )}
    >
      {checked && <Check size={10} className="text-white" strokeWidth={3} />}
    </button>
  );
}