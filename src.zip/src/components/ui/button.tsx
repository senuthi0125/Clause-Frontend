import { cn } from "@/lib/utils";
import { type ButtonHTMLAttributes, forwardRef } from "react";

interface ButtonProps extends ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: "primary" | "secondary" | "ghost" | "danger";
  size?: "sm" | "md" | "lg";
}

const variants = {
  primary: "bg-[#1a1a2e] text-white hover:bg-[#252545]",
  secondary: "border border-[#e0e0ea] bg-white text-[#3a3a4a] hover:bg-[#f8f8fb]",
  ghost: "text-[#6b6b80] hover:bg-[#f0f0f6] hover:text-[#1a1a2e]",
  danger: "bg-red-500 text-white hover:bg-red-600",
};

const sizes = {
  sm: "h-8 px-3 text-[11px] rounded-lg gap-1.5",
  md: "h-9 px-4 text-[12px] rounded-xl gap-2",
  lg: "h-11 px-5 text-[13px] rounded-xl gap-2",
};

const Button = forwardRef<HTMLButtonElement, ButtonProps>(
  ({ className, variant = "primary", size = "md", children, ...props }, ref) => (
    <button
      ref={ref}
      className={cn(
        "inline-flex items-center justify-center font-medium transition-all duration-150 disabled:opacity-40 disabled:cursor-not-allowed select-none",
        variants[variant],
        sizes[size],
        className
      )}
      {...props}
    >
      {children}
    </button>
  )
);
Button.displayName = "Button";
export { Button };