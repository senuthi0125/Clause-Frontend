import { cn } from "@/lib/utils";

export function Avatar({ className, children }: { className?: string; children: React.ReactNode }) {
  return (
    <div className={cn("relative flex shrink-0 overflow-hidden rounded-full", className)}>
      {children}
    </div>
  );
}

export function AvatarImage({ src, alt, className }: { src?: string; alt?: string; className?: string }) {
  if (!src) return null;
  return <img src={src} alt={alt ?? ""} className={cn("h-full w-full object-cover", className)} />;
}

export function AvatarFallback({ className, children }: { className?: string; children: React.ReactNode }) {
  return (
    <div className={cn("flex h-full w-full items-center justify-center bg-[#6366f1] text-white text-[11px] font-semibold", className)}>
      {children}
    </div>
  );
}