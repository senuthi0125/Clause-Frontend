import {
  LayoutDashboard, CalendarDays, FileText, ShieldAlert,
  Brain, Settings, Users, PlusSquare,
} from "lucide-react";
import { NavLink, useNavigate } from "react-router-dom";
import { useEffect, useState } from "react";
import { contractsApi } from "@/services/api";
import type { Contract } from "@/types";

const navLinks = [
  { label: "Dashboard", to: "/dashboard", icon: LayoutDashboard },
  { label: "Calendar", to: "/calendar", icon: CalendarDays },
  { label: "Contracts", to: "/contracts", icon: FileText },
  { label: "Conflict Detection", to: "/contracts/new", icon: ShieldAlert },
  { label: "AI Analysis", to: "/contracts", icon: Brain },
  { label: "Settings", to: "/dashboard", icon: Settings },
  { label: "Admin", to: "/dashboard", icon: Users },
];

const dotColors = ["bg-lime-400", "bg-yellow-400", "bg-violet-400", "bg-blue-400", "bg-pink-400"];
const placeholders = ["Website Redesign", "Website Redesign", "Design System", "Wireframes"];

export default function Sidebar() {
  const navigate = useNavigate();
  const [recentContracts, setRecentContracts] = useState<Contract[]>([]);

  useEffect(() => {
    contractsApi.list({ per_page: 5, page: 1 })
      .then((res) => {
        const d = res.data?.data || res.data || [];
        setRecentContracts(Array.isArray(d) ? d : []);
      })
      .catch(() => {});
  }, []);

  return (
    <aside className="flex w-[220px] shrink-0 flex-col bg-[#1a1a2e] px-4 py-6">
      {/* Logo */}
      <div className="mb-7 flex items-center gap-2.5 px-2">
        <div className="flex h-7 w-7 items-center justify-center rounded-full bg-gradient-to-br from-[#6366f1] via-[#8b5cf6] to-[#06b6d4]">
          <span className="text-[11px] font-black text-white">C</span>
        </div>
        <span className="text-[22px] font-bold tracking-tight text-white">clause</span>
      </div>

      {/* Nav */}
      <nav className="space-y-0.5">
        {navLinks.map(({ label, to, icon: Icon }) => (
          <NavLink
            key={label}
            to={to}
            className={({ isActive }) =>
              `flex items-center gap-3 rounded-xl px-3 py-2.5 text-[12.5px] font-medium transition-all ${
                isActive
                  ? "bg-white/10 text-white"
                  : "text-[#7070a0] hover:bg-white/5 hover:text-white/90"
              }`
            }
          >
            <Icon size={15} strokeWidth={1.8} />
            {label}
          </NavLink>
        ))}
      </nav>

      {/* My Contracts */}
      <div className="mt-8">
        <div className="mb-3 flex items-center justify-between px-1">
          <span className="text-[10px] font-semibold uppercase tracking-widest text-[#40405a]">
            My Contracts
          </span>
          <button onClick={() => navigate("/contracts/new")} className="text-[#40405a] transition hover:text-white">
            <PlusSquare size={13} />
          </button>
        </div>
        <div className="space-y-2">
          {recentContracts.length > 0
            ? recentContracts.map((c, i) => (
                <button key={c._id} onClick={() => navigate(`/contracts/${c._id}`)}
                  className="flex w-full items-center gap-2.5 rounded-lg px-2 py-1.5 text-left transition hover:bg-white/5">
                  <span className={`h-2 w-2 shrink-0 rounded-full ${dotColors[i % dotColors.length]}`} />
                  <span className="truncate text-[12px] text-[#6060a0]">{c.title}</span>
                </button>
              ))
            : placeholders.map((name, i) => (
                <div key={i} className="flex items-center gap-2.5 px-2 py-1.5">
                  <span className={`h-2 w-2 shrink-0 rounded-full ${dotColors[i % dotColors.length]}`} />
                  <span className="text-[12px] text-[#40405a]">{name}</span>
                </div>
              ))}
        </div>
      </div>

      {/* Bottom card */}
      <div className="mt-auto pt-6">
        <div className="rounded-2xl bg-[#22223a] p-4 text-center">
          <div className="mx-auto mb-2 flex h-9 w-9 items-center justify-center rounded-full bg-[#f5d84b] text-lg">💡</div>
          <p className="text-[12px] font-semibold text-white">Thoughts Time</p>
          <p className="mt-1.5 text-[10px] leading-4 text-[#50507a]">
            We don't have any notice for you, till then you can share your thoughts with your peers.
          </p>
          <button className="mt-3 text-[11px] font-semibold text-[#7070b0] transition hover:text-white">
            Write a message
          </button>
        </div>
      </div>
    </aside>
  );
}