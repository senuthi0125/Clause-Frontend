import { Bell, ChevronDown, LogOut } from "lucide-react";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { useUser, useClerk } from "@clerk/clerk-react";
import { useNavigate } from "react-router-dom";
import { useEffect, useState } from "react";
import { notificationsApi } from "@/services/api";

export default function Topbar({ title }: { title: string }) {
  const { user } = useUser();
  const { signOut } = useClerk();
  const navigate = useNavigate();
  const [unread, setUnread] = useState(0);
  const [menu, setMenu] = useState(false);

  useEffect(() => {
    notificationsApi.getUnreadCount().then((r) => setUnread(r.data?.count ?? 0)).catch(() => {});
  }, []);

  const initials = user ? `${user.firstName?.[0] ?? ""}${user.lastName?.[0] ?? ""}` : "U";

  return (
    <header className="flex items-center justify-between border-b border-[#f0f0f5] bg-white px-6 py-4">
      <h1 className="text-[18px] font-semibold text-[#1a1a2e]">{title}</h1>
      <div className="flex items-center gap-3">
        <button onClick={() => navigate("/notifications")}
          className="relative rounded-xl p-2 text-[#8a8a9a] transition hover:bg-[#f5f5f9] hover:text-[#1a1a2e]">
          <Bell size={17} />
          {unread > 0 && (
            <span className="absolute -right-0.5 -top-0.5 flex h-4 w-4 items-center justify-center rounded-full bg-red-500 text-[9px] font-bold text-white">
              {unread > 9 ? "9+" : unread}
            </span>
          )}
        </button>
        <div className="relative">
          <button onClick={() => setMenu(!menu)}
            className="flex items-center gap-2.5 rounded-xl px-2 py-1.5 transition hover:bg-[#f5f5f9]">
            <div className="text-right leading-snug">
              <p className="text-[12px] font-semibold text-[#1a1a2e]">{user?.fullName ?? "User"}</p>
              <p className="text-[10px] text-[#8a8a9a]">U.P, India</p>
            </div>
            <Avatar className="h-8 w-8">
              <AvatarImage src={user?.imageUrl} />
              <AvatarFallback>{initials}</AvatarFallback>
            </Avatar>
            <ChevronDown size={13} className="text-[#8a8a9a]" />
          </button>
          {menu && (
            <>
              <div className="fixed inset-0 z-40" onClick={() => setMenu(false)} />
              <div className="absolute right-0 top-full z-50 mt-2 w-48 rounded-2xl border border-[#ebebf0] bg-white p-2 shadow-xl">
                <button onClick={() => { signOut(); setMenu(false); }}
                  className="flex w-full items-center gap-2 rounded-xl px-3 py-2.5 text-[12px] text-red-600 transition hover:bg-red-50">
                  <LogOut size={13} /> Sign out
                </button>
              </div>
            </>
          )}
        </div>
      </div>
    </header>
  );
}